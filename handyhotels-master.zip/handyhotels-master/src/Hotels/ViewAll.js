import React from 'react'

export default function ViewAll() {
  return (
    <div>ViewAll</div>
  )
}
